Lista Bzyk83 HB 13E 13.05.2026 - wersja spłaszczona do instalacji

Pliki są bez katalogu nadrzędnego. Po rozpakowaniu mają trafić bezpośrednio do /etc/enigma2/.

Instalacja ręczna:
unzip -o /tmp/Lista-bzyk83-hb-13E-13.05.2026-FIX.zip -d /etc/enigma2/
wget -q -O - http://127.0.0.1/web/servicelistreload || killall -9 enigma2

Jeżeli używasz menedżera plików: nie kopiuj całego folderu, tylko zawartość folderu z plikami bouquets.tv, lamedb5 i userbouquet.*.
