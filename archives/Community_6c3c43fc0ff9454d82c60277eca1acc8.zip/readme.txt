AIO COMMUNITY — INFORMACYJNA LISTA TESTOWA 13E FTA
Data: 15.10.2026 | Autor: Paweł Pawełek / AIO Team
Strona: https://aio-iptv-projekt.pages.dev/
Panel dodawania: https://aio-iptv-projekt.pages.dev/aio-list-upload.html
Edytor: https://aio-iptv-projekt.pages.dev/aio-list-editor.html

UWAGA: To demonstracyjna, pełna paczka list Enigma2, oparta na
FTA Hot Bird 13E z autorskiej listy AIO Team z 11.10.2026.
Oprócz istniejących bukietów FTA zawiera bukiet informacyjny
w językach PL, EN, DE, FR, ES, IT, UA.
Nie zawiera adresów IPTV ani danych dostępowych.

Instalacja za pośrednictwem AIO Panel ZASTĘPUJE obecne bukiety
telewizyjne tunera. PRZED INSTALACJĄ wykonaj kopię zapasową
/etc/enigma2/. To NIE jest paczka dodająca bukiet bez zmiany innych.
Transpondery i dostępność kanałów nie były weryfikowane na żywo.

Zawartość ZIP:
  etc/enigma2/lamedb
  etc/enigma2/lamedb5
  etc/enigma2/bouquets.tv
  etc/enigma2/userbouquet.aio_community_info_world.tv
  etc/enigma2/userbouquet.vh_pl_fta.tv
  etc/enigma2/userbouquet.vh_fta_13e.tv
  readme.txt

Każda zgłoszona lista musi przejść kontrolę ZIP i moderację.
Nie publikuj adresów do nielegalnych transmisji lub cudzych haseł.
Nazwa listy podczas późniejszych aktualizacji musi pozostać taka sama.
